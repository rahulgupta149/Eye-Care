$(".mobile-menu-toggle").click(function () {
    $("body").addClass("mmenu-active");
});

$(".mobile-menu-close").click(function () {
    $("body").removeClass("mmenu-active");
});